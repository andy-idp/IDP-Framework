<?php
$this->translation = array(
    // Cookies
    "cookie_notice" => "En poursuivant votre navigation sur ce site, vous acceptez l'utilisation de cookies afin d'améliorer votre expérience.",
    "cookie_notice_close" => "Fermer",
    "cookie_notice_page" => "En savoir plus",
    "page_mentions_legales_h1" => "Mentions légales",
    "page_mentions_legales_url" => "mentions-legales",
    "" => "",
    "" => "",
);
