<?php
$this->translation = array(
    // Cookies
    "cookie_notice" => "By continuing your browsing on this site, you agree to the use of cookies to enhance your experience.",
    "cookie_notice_close" => "Close",
    "cookie_notice_page" => "Read more",
    "page_mentions_legales_h1" => "Legal Notice",
    "page_mentions_legales_url" => "legale-notice",
    "" => "",
    "" => "",
);
